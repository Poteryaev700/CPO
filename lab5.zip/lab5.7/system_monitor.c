#include <stdio.h>
#include <stdlib.h>
#include <sys/statvfs.h>

#define TEMP_PATH "/sys/class/thermal/thermal_zone0/temp"
#define MEMINFO_PATH "/proc/meminfo"

int main(void)
{
    FILE *temp_file, *meminfo_file;
    struct statvfs disk_info;
    double cpu_temp;
    long mem_total, mem_free;
    int ret;

    // Get CPU temperature
    temp_file = fopen(TEMP_PATH, "r");
    if (temp_file == NULL) {
        fprintf(stderr, "Failed to open %s\n", TEMP_PATH);
        return 1;
    }
    fscanf(temp_file, "%lf", &cpu_temp);
    cpu_temp /= 1000;
    printf("CPU temperature: %.1f °C\n", cpu_temp);
    fclose(temp_file);

    // Get total and free memory
    meminfo_file = fopen(MEMINFO_PATH, "r");
    if (meminfo_file == NULL) {
        fprintf(stderr, "Failed to open %s\n", MEMINFO_PATH);
        return 1;
    }
    ret = fscanf(meminfo_file, "MemTotal: %ld", &mem_total);
    if (ret == EOF) {
        fprintf(stderr, "Error reading MemTotal from %s\n", MEMINFO_PATH);
        fclose(meminfo_file);
        return 1;
    }
    ret = fscanf(meminfo_file, " MemFree: %ld", &mem_free);
    if (ret == EOF) {
        fprintf(stderr, "Error reading MemFree from %s\n", MEMINFO_PATH);
        fclose(meminfo_file);
        return 1;
    }
    fclose(meminfo_file);
    printf("Total memory: %ld kB\n", mem_total);
    printf("Free memory: %ld kB\n", mem_free);

    // Get free disk space
    if (statvfs("/", &disk_info) == -1) {
        fprintf(stderr, "Failed to get disk stats\n");
        return 1;
    }
    printf("Free disk space: %.2f GB\n", (double)disk_info.f_bfree * disk_info.f_frsize / 1024 / 1024 / 1024);

    return 0;
}
